from django.contrib import admin
from src.mail.models import Email

admin.site.register(Email)